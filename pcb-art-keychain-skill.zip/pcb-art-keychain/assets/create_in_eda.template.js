// Run once through Advanced > Run Script in a NEW EMPTY PCB document.
// This creates native EDA primitives. It is not a Gerber export.
(async () => {
  try {
    // Values checked against the bundled focused API reference; do not guess.
    const L={TOP:1,BOTTOM:2,TOP_SILKSCREEN:3,BOTTOM_SILKSCREEN:4,TOP_SOLDER_MASK:5,BOTTOM_SOLDER_MASK:6,BOARD_OUTLINE:11,MULTI:12};
    const DOCUMENT_PCB=3, PAD_NORMAL=0;
    const doc=await eda.dmt_SelectControl.getCurrentDocumentInfo();
    if(!doc||doc.documentType!==DOCUMENT_PCB)throw new Error('请先打开并聚焦工程中的 PCB 图页，再运行脚本。');
    const apiNames=['pcb_PrimitivePolyline','pcb_PrimitiveImage','pcb_PrimitivePad','pcb_PrimitiveLine','pcb_PrimitiveArc','pcb_PrimitiveFill','pcb_PrimitiveRegion','pcb_PrimitiveString','pcb_PrimitiveVia','pcb_PrimitiveComponent','pcb_PrimitivePour','pcb_PrimitiveDimension','pcb_PrimitiveObject'];
    const existing=await Promise.all(apiNames.map(name=>{
      const api=eda[name];
      if(!api||typeof api.getAllPrimitiveId!=='function')throw new Error('当前 EDA API 不支持空白检查：'+name+'。请核对版本和官方签名，不要移除检查强行运行。');
      return api.getAllPrimitiveId();
    }));
    if(existing.some(items=>!Array.isArray(items)))throw new Error('无法确认 PCB 是否空白，已停止。');
    if (existing.some(items => items.length !== 0)) {
      throw new Error('检测到已有图元。请切换到新的空白 PCB；本脚本不会覆盖已有设计。');
    }
    const g = __GEOMETRY_JSON__;
    const poly = eda.pcb_MathPolygon.createPolygon(g.outline);
    if (!poly) throw new Error('板框多边形创建失败');
    if (!(await eda.pcb_PrimitivePolyline.create('', L.BOARD_OUTLINE, poly, 4, false))) {
      throw new Error('板框图元创建失败');
    }
    let count = 0;
    for (const [layer, key] of [[L.TOP,'copperFront'],[L.TOP_SOLDER_MASK,'front'],[L.TOP_SILKSCREEN,'silkFront'],[L.BOTTOM,'copperBack'],[L.BOTTOM_SOLDER_MASK,'back'],[L.BOTTOM_SILKSCREEN,'silkBack']]) {
      for (const source of g[key]||[]) {
        const polygon = eda.pcb_MathPolygon.createComplexPolygon(source);
        if (!polygon) throw new Error('图案多边形创建失败');
        const a = source[0].filter(v => typeof v === 'number');
        const xs = a.filter((v,i) => i%2===0), ys = a.filter((v,i) => i%2===1);
        const l = Math.min(...xs), r = Math.max(...xs), b = Math.min(...ys), t = Math.max(...ys);
        const mirror=[L.BOTTOM,L.BOTTOM_SOLDER_MASK,L.BOTTOM_SILKSCREEN].includes(layer);
        const image = await eda.pcb_PrimitiveImage.create(l,t,polygon,layer,r-l,t-b,0,mirror,false);
        if (!image) throw new Error('图案创建失败，层号：'+layer);
        count++;
      }
    }
    const d = g.hole[2];
    const hole = await eda.pcb_PrimitivePad.create(
      L.MULTI,'H1',g.hole[0],g.hole[1],0,['ELLIPSE',d,d],'',['ROUND',d],0,0,0,false,PAD_NORMAL
    );
    if (!hole) throw new Error('NPTH 挂孔创建失败');
    const saved = await eda.pcb_Document.save();
    await eda.pcb_Document.zoomToBoardOutline();
    eda.sys_Dialog.showInformationMessage(
      '已生成板框、'+count+'个图案图元和 '+(d*0.0254).toFixed(2)+' mm 非金属化挂孔。云端保存'+(saved?'成功':'未确认，请手动保存')+'。请导入更新预览并检查顶底两面。',
      'PCB 图案挂件','知道了'
    );
  } catch (error) {
    eda.sys_Dialog.showInformationMessage(
      String(error)+'\n执行中断可能留下部分图元；先核对当前文档，不要盲目重跑。',
      'PCB 生成检查','知道了'
    );
  }
})();
