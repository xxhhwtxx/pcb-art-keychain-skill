# 本地工具与复现命令

命令从 skill 文件夹运行；也可用脚本完整路径在任意任务目录运行。输入输出由命令行指定，已有非空输出目录拒绝覆盖。脚本没有账户、工程 UUID、临时附件绝对路径或 Windows 字体依赖。

## 环境

Python 3.10+，NumPy、Pillow、OpenCV、Shapely 2.x。优先使用已有环境；缺少时在任务虚拟环境安装：

```text
python -m pip install -r scripts/requirements.txt
```

Node.js 仅用于 `node --check` 语法验证，用户在 EDA 运行脚本不需要另装 Node、API 桥或浏览器控制扩展。没有 Node 时仍可交付，明确尚未完成该语法检查。

## 1. 几何恢复：精确复现

```text
python scripts/build_pcb_art.py --geometry assets/example-kuromi-clean.json --out work/kuromi-clean
node --check work/kuromi-clean/create_in_eda.js
```

保持 JSON 中的板框、孔、正反面及工艺元数据，不重新分色。`--geometry` 不与图像蒙版或 `--back` 混用；配色来自 JSON 的 `process`，命令行默认颜色不覆盖它。本案例正面紫白金，背面紫金。

## 2. 从同画布蒙版生成

```text
python scripts/build_pcb_art.py --image character.png --silhouette-mask silhouette.png --gold-front-mask gold-front.png --silk-front-mask white-front.png --mask-color purple --silk-color white --back gold-only --width 55.6 --height 66.2 --hole 2 --out work/design-v1
```

- 所有蒙版与原图保持相同画布宽高。黑色/灰度<128且alpha>180表示该层图形，白色或透明表示无图形。
- 透明图可省略轮廓蒙版，使用alpha。完全不透明白底图须明确 `--background white` 或提供轮廓蒙版；白底阈值默认230，只找外轮廓，不负责分色。
- 轮廓填实单个外边界；脸部白色不会变成材料孔。分离装饰须在轮廓蒙版中合理连接，脚本不静默删除。
- `--art-mask` 是旧版前面金色蒙版别名，与 `--gold-front-mask` 二选一。
- `--legacy-gold-detection` 只用于已知透明白金素材，不用于猜黑线、灰帽或紫色衣服的分色。

背面必须明确选择：

| `--back` | 行为 |
|---|---|
| `full` | 复制正面金色与丝印到共同物理坐标 |
| `gold-only` | 复制金色，不复制白丝印 |
| `none` | 无金色/丝印，仅用户要求空白背面时使用 |
| `custom` | 使用 `--gold-back-mask`、`--silk-back-mask`，至少一个 |

独立背面也使用共同板坐标。背面文字需要按观看方向准备内容，不能把所有底层数据无条件再镜像。

## 3. 白金示例

```text
python scripts/build_pcb_art.py --image assets/example-white-gold.png --legacy-gold-detection --back full --mask-color white --width 46.5 --height 55.6 --hole 2 --gold-hole-ring --out work/white-gold-v2
```

旧白金识别条件为alpha>180、B<180、R>85、G<225。新版挂耳和细节保护已改变；实际尺寸、面积必须用新输出，不沿用旧版数值。

本包验证上述命令得到约40.81×55.60mm，几何检查通过，双面露金约24.16%，**超过默认20%核算阈值**。工具保留图案并提示超限，这份白金示例不能直接作为免费方案。

## 参数取舍

| 参数 | 默认/用途 |
|---|---|
| width/height | 46.5/55.6mm，含挂耳最大包络，等比缩放 |
| hole/ear-wall | 2/1.7mm，实际壁厚由几何检查统计 |
| ear-x-fraction | 0.5，挂耳横向位置比例 |
| ear-shift-y-mm | 0，在局部头顶挂耳基础上移动；正值向下 |
| outline-margin | 0.9mm，外轮廓扩边 |
| copper-mode | solid连续铜基底；art为稀疏铜，须检查岛间距 |
| copper-edge/copper-hole | 0.34/0.32mm，铜避板边与孔 |
| silk-clearance | 0.12mm，丝印避金色开窗 |
| erosion/min-detail/min-island-area | 均0：默认不腐蚀、不全图开运算、不删小图案 |
| rounding | 0，可少量向外圆整；不是去毛刺工具 |
| reinforce-thin | 0，例如0.018mm为窄线加法加强，不用检测用的开运算结果替换原图 |
| silk-pinhole-area | 0，明确启用后只填小丝印内孔，再避让金色；必须看局部 |
| gold-hole-ring | 默认关闭，挂孔可选金色装饰环 |
| mask-color/silk-color | white/white，示意与元数据，不自动替用户选择订单工艺 |
| thickness | 1.6mm，制造建议元数据，不证明已设置实际订单板厚 |
| gold-limit | 0.20，配置阈值；超限提示，不删图，不证明优惠资格 |

非零腐蚀、最小细节、面积删除会损失图案，只在用户明确取舍后启用。检查 `raw_gold_preserved_percent`；它针对提取后的矢量区域，不是位图每一像素或生产良率。小于一个有效闭合像素轮廓的孤立噪点不能成为稳定工程图形。

坐标编码后再检查有效性。只允许校正面积<1e-5mm²且最大位移<0.01mm的序列化细缝；超过范围停止。输入任意损坏 JSON 不使用无限制 `buffer(0)` 修复。

## 输出

| 文件 | 含义 |
|---|---|
| geometry.json | 板框、真实孔、双面铜/开窗/丝印及元数据 |
| checks.json | 尺寸、壁厚、露铜面积、间距、越界、开窗无铜、丝印交叠 |
| create_in_eda.js | 新空白 PCB 的原生图元脚本 |
| manufacturing_requirements.json、下单工艺要求.txt | 目标表面处理、尺寸和配色；实际订单尚待确认，不自动设置沉金 |
| preview.png、front.svg、back.svg | 同制造几何预览，背面已按翻面方向显示 |
| board_outline.dxf | mm单位闭合外板框，不含钻孔 |
| layer_*.png | 同画布图层蒙版，黑色代表图形 |
| placement.json | 蒙版共同物理尺寸与位置 |

`passed_geometry_checks=false` 先修复原因。铜距板边0.3mm、孔边0.2mm、孔材料1mm、丝印距开窗0.1mm是本工具初步筛查值，不替代当前工厂规范。细线、阻焊桥、微型徽章、铣槽和窄颈须另检。

金色预览是假定选用沉金时的配色示意；生产订单仍须选择沉金 ENIG。工艺元数据缺失时，要求文件标记“未指定”。看见金色但实物无金色的排查顺序见 [manufacturing-finish.md](manufacturing-finish.md)。

## 局部修复与补丁

```text
python scripts/polish_art.py --geometry assets/example-kuromi-original.json --repairs assets/example-kuromi-repairs.json --out work/repaired
python scripts/build_pcb_art.py --geometry work/repaired/geometry.json --out work/repaired-full
python scripts/make_patch.py --before assets/example-kuromi-original.json --after work/repaired/geometry.json --out work/patch_in_eda.js
node --check work/patch_in_eda.js
```

先看局部对比，再交付补丁。旧版本不同或用户已移动图案时不强行套用。补丁只替换 IMAGE；板框/孔变化时改新 PCB 重建。详见 [repair.md](repair.md)。

## 可选直接 Gerber

优先从已核验 EDA 工程原生导出；EDA 专用券的原生设计资格由平台审核。离线需要制造文件时：

```text
python -m pip install -r scripts/requirements-gerber.txt
python scripts/export_gerber.py --geometry work/repaired/geometry.json --out work/manufacturing
```

输出Gerber.zip、Gerber/及解析报告，默认用独立 Gerbonara 回读各图层、板框中心线和 NPTH。每层区域差异>0.002mm²停止。空底丝印是有效空层，不是背面图案丢失。

无解析器可明确选择 `--skip-parser`，但报告“未独立解析”。报告标记 `native_eda_export=false`；这不是 EDA 原生导出、完整 DFM 或优惠资格证明。
