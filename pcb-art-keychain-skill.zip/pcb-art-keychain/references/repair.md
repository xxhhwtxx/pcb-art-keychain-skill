# 局部去毛刺与已有PCB补丁

先区分独立小点、连在轮廓上的尖点、像素台阶、图层错位和预览缓存。全图阈值/腐蚀/开运算能抹掉蕾丝、裙褶、睫毛；对复杂线稿优先局部处理。

## 选择修法

| 问题 | 修法 |
|---|---|
| 独立噪点 | 按明确位置和面积去掉，保留有意义的小圆点/徽章 |
| 眼睛底部小尖点 | 只平滑实心眼睛下部，睫毛与顶部原样保留 |
| 椭圆鼻圈不圆 | 用同尺寸外椭圆减去同心内椭圆，保留中空鼻子 |
| 白区小缺口 | 在原白色区域内部补偿，再避让新金色 |
| 大范围断线 | 回到原图/蒙版恢复线，不用加强半径掩盖错误分色 |
| 预览旧图 | 导入更新，不重建或重复叠加图元 |

## 通用修复工具

`polish_art.py` 使用物理mm坐标，Y向下。每个 `seed_mm` 必须落在目标实际填色多边形内部，不能在孔内或边界上。不要把本案例坐标套用到另一张图。

配置结构：

```json
{
  "gold_limit": 0.20,
  "silk_clearance_mm": 0.12,
  "repairs": [
    {
      "kind": "smooth-bottom",
      "seed_mm": [18.4, 34.9],
      "below_y_mm": 34.0,
      "radius_mm": 0.11,
      "simplify_mm": 0.035,
      "faces": ["front", "back"],
      "white_seed_mm": [25.0, 34.9]
    }
  ]
}
```

上述坐标只是结构例子，不直接运行。可运行的真实案例配置在 `assets/example-kuromi-repairs.json`。

- `smooth-bottom`：只平滑 `below_y_mm` 以下的眼睛部分；可用 `region_mm:[left,top,right,bottom]` 更明确限制。
- `smooth`：平滑完整被选组件，适合实心装饰，不能用于未知的细线集合。
- `ellipse-ring`：必须有恰好一个内孔，按现有边界尺寸重建同心椭圆。
- `faces`：默认front/back；独立背面图案应分别提供对应坐标，不能假定相同位置存在相同组件。
- `white_seed_mm`：该面有丝印时必须指定，落在周围白色组件内部；其外轮廓限定补偿范围，防止涂白相邻紫色道具。
- `max_component_area_mm2`：默认100mm²，防止误选连成大块的全身线稿；确有理由时可调整并核对范围。

默认0.11mm局部圆整半径来自本案例，不是所有图的最优值。工具记录指定区域之外变更面积，超过数值误差就停止。金色和白丝印最终仍须通过几何检查。

## 从源图坐标定位

若JSON包含 `source_transform`：

```text
x_mm = (x_source_px - crop_left_px) × mm_per_source_pixel + offset_x_mm
y_mm = (y_source_px - crop_top_px) × mm_per_source_pixel + offset_y_mm
```

转换后的物理坐标用于repair配置；不要再反转Y。编码进EDA的JSON时才用 `y_mil=-y_mm/0.0254`。

## 生成修复版本和补丁

```text
python scripts/polish_art.py --geometry assets/example-kuromi-original.json --repairs assets/example-kuromi-repairs.json --out work/local-fixed
python scripts/build_pcb_art.py --geometry work/local-fixed/geometry.json --out work/local-fixed-full
python scripts/make_patch.py --before assets/example-kuromi-original.json --after work/local-fixed/geometry.json --out work/patch_in_eda.js
```

`polish_art.py` 输出完整新几何、区域变更报告与局部对比。`build_pcb_art.py` 给完整重建脚本。`make_patch.py` 给现有板IMAGE补丁，只有用户已有板与before版本匹配时使用；可加 `--document-uuid` 限定目标图页。

补丁识别的是图层数量、BBox、旋转、镜像，不是完整形状哈希。人工修改后即使BBox未变，也不能据此认定形状仍匹配；应查确切对象或在新PCB重建。重复执行有时因数量/位置变化停止，有时会再替换为相同形状；都不应把反复运行当成排错步骤。

目标BBox重复时工具拒绝生成，以免删错对象。板框/孔改变也拒绝生成，因为IMAGE补丁不能改钻孔。完成后导入更新、核对两面、保存、重新导出Gerber。
