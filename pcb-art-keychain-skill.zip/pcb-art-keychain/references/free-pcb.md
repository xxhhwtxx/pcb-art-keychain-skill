# 免费条件与沉金面积

活动、券种、尺寸、板色、次数、运费和附加选项会变化。这是公式与查询入口，不是永久规则。每次给出免费结论时重新查当前官网与账户券；没有账户信息不承诺0元。

## 正确公式

```text
M = board_outline minus NPTH hole
A_top = area(top_copper ∩ top_mask_opening ∩ M)
A_bottom = area(bottom_copper ∩ bottom_mask_opening ∩ M)
ratio = (A_top + A_bottom) / (2 × area(M))
```

计算真实露铜交集，不是IMAGE包围盒、整面铜基底或图片黑像素比。NPTH没有金属化孔壁；别的金属化孔设计另按官方口径处理孔壁。

[官方面积说明](https://www.jlc.com/portal/factoryVisitDetails/58163)使用两面沉金面积与两面板面积口径。完整复制背面不会让双面平均比例翻倍。

本次修复案例：板材约2291.50mm²，各面露铜约448.62mm²，双面平均约19.58%。它只证明本地核算，不能证明账户有券、工厂采用完全相同的有效面积或订单免费。

工具默认 `--gold-limit 0.20` 来自此轮核算门槛，以后传入当前活动阈值。付费大面积沉金加价门槛与免费券门槛不同。超限先展示结果及取舍，不自动腐蚀线条。

## 下单前核对

| 项目 | 内容 |
|---|---|
| 券 | 种类、领取资格、有效期、账户已用次数/额度 |
| 板形/数量 | 最大最小尺寸、单片/拼板、异形/孔/铣槽限制、数量 |
| 层数/板厚/阻焊 | 当前券允许组合，普通白丝印与彩色丝印分别核对 |
| 沉金 | 券适用、面积口径、审核/考试等要求 |
| 来源 | EDA原生设计要求；用API创建图元后资格仍由平台审核 |
| 历史 | 重复设计、开源文件、返单/拆单限制 |
| 额外费用 | 客单号、加急、运费、附件、特殊工艺及审核报价 |

只做脚本时不强制登录；用户要核算真实订单时再查账户/下单页。没有联网也继续完成本地设计，明确优惠尚待核验。

## 官方入口

- [领券中心](https://www.jlc.com/coupons)
- [PCB+SMT券细则](https://www.jlc.com/portal/server_guide_37595.html)
- [EDA专用券问题](https://www.jlc.com/portal/server_guide_37593.html)
- [0元福利说明](https://www.jlc.com/portal/server_guide_4114.html)
- [沉金专项历史规则](https://www.jlc.com/portal/q7i42818.html)
- [附加收费](https://www.jlc.com/portal/q6i53841.html)
- [DFM面积计算](https://www.jlc.com/portal/server_guide_59791.html)
- [EDA免费PCB教程](https://wiki.lceda.cn/zh-hans/design-production/free-pcb.html)

打开后核对发布时间、生效时间与账户选项。旧视频的“紫色/沉金必定加价”或“喷锡永远免费”等不作为当前结论。
