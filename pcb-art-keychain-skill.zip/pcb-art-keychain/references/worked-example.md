# 库洛米紫白金茶会：复现案例

用户提供女仆茶会原图和博主实物参考，要求细节完整、紫白金正面、完整紫金背面、小挂孔。AI本地生成工程几何，用户手动把完整脚本录入专业版EDA，并提供眼睛/鼻圈的编辑图层截图定位毛刺。无需AI控制浏览器来创建图元。

## 案例参数

- 55.60×65.89mm，含中间小挂耳，保持原图比例。
- Ø2.00mm NPTH；孔边材料约1.591mm。
- 两面连续铜基底；铜至板边约0.331mm、至孔约0.314mm。
- 正面38个金色开窗组件、107个普通白丝印组件；背面38个金色开窗组件，不放白丝印。
- 共185个IMAGE，加一条板框和一个钻孔对象。
- 眼睛/鼻圈局部修复后双面沉金平均约19.58%，未据此承诺免费。

## 随包材料

| 文件 | 用途 |
|---|---|
| example-kuromi-source.png | 用户视觉素材，显示灰帽/粉腮红/紫蝴蝶结不等于制造颜色 |
| example-kuromi-original.json | 修复前共同坐标制造几何 |
| example-kuromi-clean.json | 眼睛底沿/鼻圈/白区已局部修复的完整几何 |
| example-kuromi-repairs.json | 针对此案例的物理坐标修复配置 |
| example-kuromi-face-comparison.png | 原版与修复后的真实多边形对比 |
| example-kuromi-preview.png | 修复版正反面工艺示意 |
| example-kuromi-create.js | 新空白PCB完整生成脚本 |
| example-kuromi-manufacturing_requirements.json / example-kuromi-order-requirements.txt | 此案例的目标工艺要求，实际订单仍须单独核对 |
| example-kuromi-patch.js | 与original版本匹配的现有PCB局部补丁 |

## 复现

```text
python scripts/build_pcb_art.py --geometry assets/example-kuromi-clean.json --out work/example-restored
python scripts/polish_art.py --geometry assets/example-kuromi-original.json --repairs assets/example-kuromi-repairs.json --out work/example-repaired
python scripts/make_patch.py --before assets/example-kuromi-original.json --after work/example-repaired/geometry.json --out work/example-patch.js
```

修复工具从original重算时与已保存clean版本可有极小的坐标圆整差异；几何与局部范围检查均须通过，不以PNG像素完全相等作为工程一致性证明。

## 本次避免的失误

1. 旧流程全图开运算/收缩会切掉蕾丝，故默认保留线条。
2. 保留所有原黑线也会把压缩毛刺保留下来，故对实心眼睛底部局部平滑，并重建规则鼻圈。
3. 只改开窗会留下原白区尖角留白，故同步补偿白丝印。
4. 白区补偿须限制在原白脸外轮廓内，避免涂白旁边心形茶壶装饰。
5. 量化坐标后回读，修正面积约2.8e-9mm²、最大位移约0.0054mm的序列化细缝；大范围损坏不自动修。
6. 底面按共同坐标创建，由观看翻面与IMAGE参数体现方向，不双重镜像。

## 验证边界

该包通过本地几何恢复、局部修复范围、生成/补丁语法和独立Gerber解析检查。JS模拟执行检查文档/空白拒绝、创建失败、补丁匹配和保存状态；模拟不是实际EDA兼容性证明。

原始设计在用户EDA显示并有用户截图；当前随包升级模板、通用补丁及修复版没有被AI在用户云端再次执行。用户运行后仍需核验保存和实际2D/3D、DRC。直接Gerber输出不是EDA原生导出；工厂DFM、免费资格和实物良率未验证。

角色、坐标、尺寸、颜色都是案例数据。新任务须重新分色、定位局部与核验尺寸，不照搬这些参数。
