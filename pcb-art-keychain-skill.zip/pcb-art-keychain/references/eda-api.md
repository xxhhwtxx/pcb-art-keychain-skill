# 本任务使用的 EDA API

此文件是本轮官方SDK资料的相关签名摘录，便于其他AI离线生成脚本；不是完整SDK。菜单和部分旧调用曾在专业版V4.1.60观察，升级模板的新增空白检查与sys_Dialog调用尚需实际EDA运行核验。Beta接口和软件版本可能变化，修改调用前查当前官方文档。

PCB长度单位mil，1mil=0.0254mm。已核对枚举：TOP=1、BOTTOM=2、TOP_SILKSCREEN=3、BOTTOM_SILKSCREEN=4、TOP_SOLDER_MASK=5、BOTTOM_SOLDER_MASK=6、BOARD_OUTLINE=11、MULTI=12；文档类型PCB=3，PadType.NORMAL=0。模板以具名常量映射这些值，不依赖Run Script里存在全局枚举对象。

IMAGE的x/y是BBox左上，使用[minX,maxY]及宽高。每个复合多边形含外环及内孔；底面IMAGE使用模板的horizonMirror=true组合，并由实际底面预览核对位置。该显示约定不适用于Gerber额外镜像。

NPTH通过Pad.create的ROUND真实钻孔及metallization=false创建，不能用图形留白代替。空白检查各getAllPrimitiveId参数均可省略，但返回Promise，必须await。SYS_Dialog为当前信息窗；旧SYS_MessageBox已弃用，不能因旧案例可用而将其写成长期稳定接口。

## DMT_SelectControl.getCurrentDocumentInfo

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.dmt_selectcontrol.getcurrentdocumentinfo.html)

```typescript
function getCurrentDocumentInfo(): Promise<IDMT_EditorDocumentItem | undefined>;
```

## PCB_MathPolygon.createPolygon

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_mathpolygon.createpolygon.html)

```typescript
function createPolygon(polygon: TPCB_PolygonSourceArray): IPCB_Polygon | undefined;
```

## PCB_MathPolygon.createComplexPolygon

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_mathpolygon.createcomplexpolygon.html)

```typescript
function createComplexPolygon(
	complexPolygon:
		| TPCB_PolygonSourceArray
		| Array<TPCB_PolygonSourceArray>
		| IPCB_Polygon
		| Array<IPCB_Polygon>,
): IPCB_ComplexPolygon | undefined;
```

## PCB_PrimitivePolyline.create

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivepolyline.create.html)

```typescript
function create(
	net: string,
	layer: TPCB_LayersOfLine,
	polygon: IPCB_Polygon,
	lineWidth?: number,
	primitiveLock?: boolean,
): Promise<IPCB_PrimitivePolyline | undefined>;
```

## PCB_PrimitivePolyline.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivepolyline.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	net?: string,
	layer?: TPCB_LayersOfLine,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveImage.create

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveimage.create.html)

```typescript
function create(
	x: number,
	y: number,
	complexPolygon:
		| TPCB_PolygonSourceArray
		| Array<TPCB_PolygonSourceArray>
		| IPCB_Polygon
		| IPCB_ComplexPolygon,
	layer: TPCB_LayersOfImage,
	width?: number,
	height?: number,
	rotation?: number,
	horizonMirror?: boolean,
	primitiveLock?: boolean,
): Promise<IPCB_PrimitiveImage | undefined>;
```

## PCB_PrimitiveImage.getAll

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveimage.getall.html)

```typescript
function getAll(
	layer?: TPCB_LayersOfImage,
	primitiveLock?: boolean,
): Promise<Array<IPCB_PrimitiveImage>>;
```

## PCB_PrimitiveImage.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveimage.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfImage,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveImage.delete

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveimage.delete.html)

```typescript
function delete(primitiveIds: string | IPCB_PrimitiveImage | Array<string> | Array<IPCB_PrimitiveImage>): Promise<boolean>;
```

## IPCB_PrimitiveImage.getState_X

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_x.html)

```typescript
function getState_X(): number;
```

## IPCB_PrimitiveImage.getState_Y

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_y.html)

```typescript
function getState_Y(): number;
```

## IPCB_PrimitiveImage.getState_Width

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_width.html)

```typescript
function getState_Width(): number;
```

## IPCB_PrimitiveImage.getState_Height

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_height.html)

```typescript
function getState_Height(): number;
```

## IPCB_PrimitiveImage.getState_Rotation

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_rotation.html)

```typescript
function getState_Rotation(): number;
```

## IPCB_PrimitiveImage.getState_HorizonMirror

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_horizonmirror.html)

```typescript
function getState_HorizonMirror(): boolean;
```

## IPCB_PrimitiveImage.getState_PrimitiveId

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.ipcb_primitiveimage.getstate_primitiveid.html)

```typescript
function getState_PrimitiveId(): string;
```

## PCB_PrimitivePad.create

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivepad.create.html)

```typescript
function create(
	layer: TPCB_LayersOfPad,
	padNumber: string,
	x: number,
	y: number,
	rotation?: number,
	pad?: TPCB_PrimitivePadShape,
	net?: string,
	hole?: TPCB_PrimitivePadHole | null,
	holeOffsetX?: number,
	holeOffsetY?: number,
	holeRotation?: number,
	metallization?: boolean,
	padType?: EPCB_PrimitivePadType,
	specialPad?: TPCB_PrimitiveSpecialPadShape,
	solderMaskAndPasteMaskExpansion?: IPCB_PrimitiveSolderMaskAndPasteMaskExpansion | null,
	heatWelding?: IPCB_PrimitivePadHeatWelding | null,
	primitiveLock?: boolean,
): Promise<IPCB_PrimitivePad | undefined>;
```

## PCB_PrimitivePad.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivepad.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfPad,
	net?: string,
	primitiveLock?: boolean,
	padType?: EPCB_PrimitivePadType,
): Promise<Array<string>>;
```

## PCB_Document.save

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_document.save.html)

```typescript
function save(): Promise<boolean>;
```

## PCB_Document.zoomToBoardOutline

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_document.zoomtoboardoutline.html)

```typescript
function zoomToBoardOutline(): Promise<boolean>;
```

## SYS_Dialog.showInformationMessage

[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.sys_dialog.showinformationmessage.html)

```typescript
function showInformationMessage(content: string, title?: string, buttonTitle?: string): void;
```

## PCB_PrimitiveLine.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveline.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	net?: string,
	layer?: TPCB_LayersOfLine,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveArc.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivearc.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	net?: string,
	layer?: TPCB_LayersOfLine,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveFill.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivefill.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfFill,
	net?: string,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveRegion.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveregion.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfRegion,
	ruleType?: Array<EPCB_PrimitiveRegionRuleType>,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveString.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivestring.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfImage,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveVia.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivevia.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(net?: string, primitiveLock?: boolean): Promise<Array<string>>;
```

## PCB_PrimitiveComponent.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivecomponent.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfComponent,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitivePour.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivepour.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	net?: string,
	layer?: TPCB_LayersOfCopper,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveDimension.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitivedimension.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfDimension,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## PCB_PrimitiveObject.getAllPrimitiveId

Beta：[官方方法页](https://prodocs.lceda.cn/cn/api/reference/pro-api.pcb_primitiveobject.getallprimitiveid.html)

```typescript
function getAllPrimitiveId(
	layer?: TPCB_LayersOfObject,
	primitiveLock?: boolean,
): Promise<Array<string>>;
```

## 几何结构

路径只使用闭合直线多边形：[x,y,"L",x2,y2,...,x,y]，单位mil，有限数值。复合多边形=[outer,hole1,...]。孔与外环绕向相反。模板传createComplexPolygon之后才创建IMAGE。

getCurrentDocumentInfo返回documentType、uuid、tabId以及可选parentProjectUuid/parentLibraryUuid；只有documentType===3才能操作PCB。不能在2D/3D预览图页上运行创建脚本。

出现方法缺失、参数不符、权限或类型错误时停止该执行，不猜签名。不要用浏览器只读evaluate修改应用内部对象，不需要为此技能默认部署API桥。
