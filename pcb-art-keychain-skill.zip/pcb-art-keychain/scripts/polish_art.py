#!/usr/bin/env python3
"""Polish explicitly selected CAD features, with local silk compensation."""
from pathlib import Path
import argparse,copy,json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from shapely.affinity import scale
from shapely.geometry import Polygon,Point,box
from shapely.ops import unary_union
import build_pcb_art as pcb

def ellipse(bounds):
    l,t,r,b=bounds
    return Polygon([((l+r)/2+(r-l)/2*math.cos(a),(t+b)/2+(b-t)/2*math.sin(a)) for a in np.linspace(0,2*math.pi,257)])

def selected(geometry,seed):
    p=Point(*seed)
    matches=[part for part in pcb.parts(geometry) if part.contains(p)]
    if len(matches)!=1:raise ValueError('Seed must be inside exactly one painted polygon, not in a hole or on its boundary')
    return matches[0]

def repair(data,config):
    result=copy.deepcopy(data)
    layers={k:pcb.decode_sources(data.get(k,[])) for k in ['front','back','silkFront','silkBack']}
    original=dict(layers);affected=[]
    for spec in config['repairs']:
        radius=float(spec.get('radius_mm',.11))
        if not 0<radius<=.5:raise ValueError('Local rounding radius must be >0 and <=0.5mm')
        for face in spec.get('faces',['front','back']):
            if face not in ('front','back'):raise ValueError('Face must be front or back')
            p=selected(layers[face],spec['seed_mm'])
            if p.area>spec.get('max_component_area_mm2',100):raise ValueError('Selected component too large; review the seed and scope before polishing')
            l,t,r,b=p.bounds
            if spec['kind']=='ellipse-ring':
                if len(p.interiors)!=1:raise ValueError('Ellipse-ring repair needs a polygon with exactly one hole')
                hl,ht,hr,hb=Polygon(p.interiors[0]).bounds
                inner=ellipse(((l+r-hr+hl)/2,(t+b-hb+ht)/2,(l+r+hr-hl)/2,(t+b+hb-ht)/2))
                new=ellipse(p.bounds).difference(inner)
                influence=box(l-.6,t-.6,r+.6,b+.6)
            elif spec['kind'] in ('smooth','smooth-bottom'):
                smooth=p.simplify(float(spec.get('simplify_mm',.035)),preserve_topology=True)
                smooth=smooth.buffer(radius,quad_segs=12).buffer(-2*radius,quad_segs=12).buffer(radius,quad_segs=12).simplify(.003,preserve_topology=True)
                region=box(*spec['region_mm']) if 'region_mm' in spec else box(l-.3,float(spec['below_y_mm']) if spec['kind']=='smooth-bottom' else t-.3,r+.3,b+.4)
                new=p.difference(region).union(smooth.intersection(region))
                influence=region.buffer(.4,quad_segs=12)
            else:raise ValueError('Unknown repair kind')
            if new.geom_type!='Polygon' or not new.is_valid:raise ValueError('Repair split or invalidated the feature; choose a smaller radius or different region')
            change=p.symmetric_difference(new)
            layers[face]=layers[face].difference(p).union(new)
            silk_key='silkFront' if face=='front' else 'silkBack'
            if not layers[silk_key].is_empty:
                if 'white_seed_mm' not in spec:raise ValueError('White silk exists: specify white_seed_mm inside the surrounding white region to compensate old burr gaps')
                white=selected(layers[silk_key],spec['white_seed_mm'])
                white_domain=Polygon(white.exterior)
                fill=influence.intersection(white_domain)
                clearance=float(config.get('silk_clearance_mm',.12))
                if clearance<.10:raise ValueError('Silk compensation clearance must be >=0.10mm')
                layers[silk_key]=layers[silk_key].difference(fill).union(fill.difference(layers[face].buffer(clearance,quad_segs=8)))
                influence=influence.union(fill)
            affected.append(influence)
    region=unary_union(affected)
    report={'native_eda_execution':'Not executed','faces':{}}
    for key in layers:
        changed=layers[key].symmetric_difference(original[key])
        if changed.difference(region).area>1e-8:raise ValueError('Repair changed geometry outside the declared regions')
        result[key]=pcb.sources(layers[key])
        report['faces'][key]={'changed_area_mm2':changed.area,'changes_outside_regions_mm2':changed.difference(region).area}
    result['revision']='Explicit local feature polishing; original board and drill retained'
    _,_,_,checks=pcb.inspect(result,config.get('gold_limit',.20))
    if not checks['passed_geometry_checks']:raise ValueError('Repair failed final geometry checks: '+json.dumps(checks['faces']))
    report['gold_surface_ratio']=checks['gold_surface_ratio']
    return result,report,original,layers,region

def comparison(old,new,region,process,path):
    l,t,r,b=region.bounds;bounds=(l-.3,t-.3,r+.3,b+.3)
    px=min(48,1400/(bounds[2]-bounds[0]))
    blank=pcb.render_mask(box(*bounds),bounds,px)
    w,h=blank.size
    canvas=Image.new('RGB',(w+60,2*h+115),'#eee9e2');draw=ImageDraw.Draw(canvas)
    font=ImageFont.load_default(size=21)
    base='#331044' if process.get('mask')=='purple' else '#fffefa'
    silk_colour='#161616' if process.get('silk')=='black' else '#fffefa'
    for i,(label,layers) in enumerate([('BEFORE',old),('AFTER - local CAD cleanup',new)]):
        loc=(30,40+i*(h+50))
        draw.text((30,loc[1]-30),label,font=font,fill='#333333')
        canvas.paste(Image.new('RGB',(w,h),base),loc,blank)
        for key,colour in [('front','#d8b554'),('silkFront',silk_colour)]:
            mask=pcb.render_mask(layers[key].intersection(box(*bounds)),bounds,px)
            canvas.paste(Image.new('RGB',(w,h),colour),loc,mask)
    canvas.save(path)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--geometry',type=Path,required=True)
    parser.add_argument('--repairs',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if args.out.exists() and (not args.out.is_dir() or any(args.out.iterdir())):parser.error('Output must be new or empty')
    try:
        data=json.loads(args.geometry.read_text(encoding='utf8'));config=json.loads(args.repairs.read_text(encoding='utf8'))
        if not isinstance(config.get('repairs'),list) or not config['repairs']:raise ValueError('Need a nonempty repairs list')
        result,report,old,new,region=repair(data,config)
        args.out.mkdir(parents=True,exist_ok=True)
        (args.out/'geometry.json').write_text(json.dumps(result,separators=(',',':'),ensure_ascii=False),encoding='utf8')
        (args.out/'repair-report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
        comparison(old,new,region,data.get('process',{}),args.out/'local-comparison.png')
    except (ValueError,OSError,KeyError,TypeError) as e:parser.exit(2,'Local repair failed: '+str(e)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
