#!/usr/bin/env python3
"""Optional direct RS-274X/NPTH export. Not an EDA-native export."""
from pathlib import Path
import argparse,json,zipfile
from shapely.geometry import Polygon
from shapely.ops import unary_union
import build_pcb_art as pcb

def export(data,out,verify=True):
    board,_,_,checks=pcb.inspect(data,1)
    if not checks['passed_geometry_checks']:raise ValueError('Geometry checks failed; do not export manufacturing data')
    minx,miny,maxx,maxy=board.bounds
    def xy(path):return [(x-minx,maxy-y) for x,y in pcb.decoded_path(path)]
    def coord(p):return f'X{round(p[0]*1e6)}Y{round(p[1]*1e6)}'
    def header(func):return ['G04 Decorative PCB art - direct geometry export*','%FSLAX46Y46*%','%MOMM*%',f'%TF.FileFunction,{func}*%','%TF.FilePolarity,Positive*%','%ADD10C,0.100000*%','D10*','G01*','%LPD*%']
    def region(path):
        points=xy(path)
        return ['G36*',coord(points[0])+'D02*',*[coord(p)+'D01*' for p in points[1:]],'G37*']
    manufacturing=out/'Gerber';manufacturing.mkdir(parents=True,exist_ok=True)
    layers=[('Art.GTL','Copper,L1,Top','copperFront'),('Art.GBL','Copper,L2,Bot','copperBack'),('Art.GTS','Soldermask,Top','front'),('Art.GBS','Soldermask,Bot','back'),('Art.GTO','Legend,Top','silkFront'),('Art.GBO','Legend,Bot','silkBack')]
    for name,func,key in layers:
        lines=header(func)
        for source in sorted(data.get(key,[]),key=lambda s:Polygon(xy(s[0])).area,reverse=True):
            lines+=['%LPD*%',*region(source[0])]
            for h in source[1:]:lines+=['%LPC*%',*region(h)]
        (manufacturing/name).write_text('\n'.join([*lines,'%LPD*%','M02*'])+'\n',encoding='ascii')
    points=xy(data['outline'])
    lines=[*header('Profile,NP'),coord(points[0])+'D02*',*[coord(p)+'D01*' for p in points[1:]],'M02*']
    (manufacturing/'Art.GKO').write_text('\n'.join(lines)+'\n',encoding='ascii')
    hx,hy,d=data['hole'];hx=hx*pcb.MIL-minx;hy=maxy+hy*pcb.MIL;d*=pcb.MIL
    drill='M48\n;FILE_FORMAT=4:6\n;TYPE=NON_PLATED\nMETRIC,LZ\nG90\nT01C'+f'{d:.6f}'+'\n%\nG05\nT01\n'+f'X{hx:.6f}Y{hy:.6f}\nM30\n'
    (manufacturing/'Art-NPTH.drl').write_text(drill,encoding='ascii')
    report={'native_eda_export':False,'independent_parser_verified':False,'process':data.get('process',{}),'layers':{}}
    if verify:
        try:
            from gerbonara import GerberFile,ExcellonFile
        except ImportError as e:raise ValueError('Install requirements-gerber.txt for independent verification; --skip-parser only creates explicitly unverified exports') from e
        for name,_,key in layers:
            parsed=GerberFile.open(manufacturing/name);restored=Polygon()
            for obj in parsed.objects:
                if not hasattr(obj,'outline'):raise ValueError('Unexpected non-region object in '+name)
                if obj.outline[0]!=obj.outline[-1]:raise ValueError('Gerber region is not closed')
                p=Polygon(obj.outline)
                if not p.is_valid:raise ValueError('Invalid read-back region in '+name)
                restored=restored.union(p) if obj.polarity_dark else restored.difference(p)
            expected=unary_union([Polygon(xy(s[0]),[xy(h) for h in s[1:]]) for s in data.get(key,[])])
            error=restored.symmetric_difference(expected).area
            if error>.002:raise ValueError('Read-back geometry mismatch: '+name+' '+str(error))
            report['layers'][name]={'region_count':len(parsed.objects),'difference_mm2':error}
        profile=GerberFile.open(manufacturing/'Art.GKO')
        if len(profile.objects)!=len(points)-1:raise ValueError('Profile segment count mismatch')
        for line,a,b in zip(profile.objects,points,points[1:]):
            if max(abs(line.x1-a[0]),abs(line.y1-a[1]),abs(line.x2-b[0]),abs(line.y2-b[1]))>2e-6:raise ValueError('Profile centreline mismatch')
        drills=ExcellonFile.open(manufacturing/'Art-NPTH.drl')
        if len(drills.objects)!=1:raise ValueError('Incorrect drill count')
        drill=drills.objects[0]
        if abs(drill.x-hx)>1e-5 or abs(drill.y-hy)>1e-5 or abs(drill.tool.diameter-d)>1e-6 or drill.tool.plated is not False:raise ValueError('NPTH read-back mismatch')
        report['independent_parser_verified']=True
        report['drill']={'count':1,'diameter_mm':d,'plated':False}
    report['limitations']='Direct geometric export, not EDA native export or factory DFM; coupon eligibility requires current account/platform review.'
    (out/'gerber-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
    (manufacturing/'process.json').write_text(json.dumps({'process':data.get('process',{}),'size_mm':checks['size_mm'],'hole_mm':checks['hole_mm'],'gold_surface_ratio':checks['gold_surface_ratio'],'native_eda_export':False,'independent_parser_verified':report['independent_parser_verified']},indent=2,ensure_ascii=False),encoding='utf8')
    with zipfile.ZipFile(out/'Gerber.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(manufacturing.iterdir()):z.write(p,p.name)
    return report

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--geometry',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--skip-parser',action='store_true')
    args=parser.parse_args()
    if args.out.exists() and (not args.out.is_dir() or any(args.out.iterdir())):parser.error('Output must be new or empty')
    try:
        data=json.loads(args.geometry.read_text(encoding='utf8'))
        report=export(data,args.out,not args.skip_parser)
    except (ValueError,OSError,KeyError,TypeError) as e:parser.exit(2,'Gerber export failed: '+str(e)+'\n')
    print(json.dumps(report,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
