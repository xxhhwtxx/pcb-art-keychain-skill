#!/usr/bin/env python3
"""Generate a guarded EDA IMAGE replacement patch from two geometry versions."""
from pathlib import Path
import argparse,json,math
import build_pcb_art as pcb

KEYS={1:'copperFront',2:'copperBack',3:'silkFront',4:'silkBack',5:'front',6:'back'}

def bbox(source):
    a=source[0][:2]+source[0][3:]
    xs,ys=a[::2],a[1::2]
    return [min(xs),max(ys),max(xs)-min(xs),max(ys)-min(ys)]

def polygon(source):
    return pcb.Polygon(pcb.decoded_path(source[0]),[pcb.decoded_path(h) for h in source[1:]])

def plan(before,after):
    if pcb.Polygon(pcb.decoded_path(before['outline'])).symmetric_difference(pcb.Polygon(pcb.decoded_path(after['outline']))).area>1e-5:
        raise ValueError('Board outline changed: generate a new blank PCB instead of an IMAGE patch')
    if any(abs(a-b)>1e-5 for a,b in zip(before['hole'],after['hole'])):
        raise ValueError('Hole changed: an IMAGE-only patch cannot change the drill')
    old_targets,new_items,counts,new_counts=[],[],{},{}
    for layer,key in KEYS.items():
        old=before.get(key,[]);new=after.get(key,[])
        counts[layer]=len(old);new_counts[layer]=len(new)
        unmatched=set(range(len(new)))
        for source in old:
            p=polygon(source);bounds=bbox(source)
            same=[i for i in unmatched if all(abs(a-b)<.02 for a,b in zip(bounds,bbox(new[i]))) and p.symmetric_difference(polygon(new[i])).area<1e-6]
            if len(same)>1:raise ValueError('Duplicate geometry prevents unambiguous patch matching')
            if same:unmatched.remove(same[0])
            else:old_targets.append({'layer':layer,'bbox':bounds})
        for i in sorted(unmatched):new_items.append({'layer':layer,'bbox':bbox(new[i]),'source':new[i]})
    if not old_targets and not new_items:raise ValueError('The two geometry versions have no IMAGE changes')
    for target in old_targets:
        all_boxes=[bbox(s) for s in before.get(KEYS[target['layer']],[])]
        if sum(all(abs(a-b)<.06 for a,b in zip(target['bbox'],b)) for b in all_boxes)!=1:
            raise ValueError('Target BBox is not unique. Use a new PCB or a specifically identified object patch')
    return {'counts':counts,'newCounts':new_counts,'oldTargets':old_targets,'newItems':new_items}

TEMPLATE='''// Run ONCE in the EXISTING matching PCB. This is not a blank-board creator.
(async()=>{
 let created=[],deletionStarted=false;
 try {
  const p=__PLAN__;
  const doc=await eda.dmt_SelectControl.getCurrentDocumentInfo();
  if(!doc||doc.documentType!==3)throw Error('请先聚焦现有 PCB 图页。');
  if(p.documentUuid&&doc.uuid!==p.documentUuid)throw Error('当前 PCB UUID 不匹配，停止修改。');
  const images={};
  for(const [layer,count] of Object.entries(p.counts)){
   images[layer]=await eda.pcb_PrimitiveImage.getAll(Number(layer));
   if(images[layer].length!==count)throw Error('图层 '+layer+' 的图元数量不符合修复前版本，停止修改。');
  }
  const oldIds=[];
  for(const target of p.oldTargets){
   const matches=images[target.layer].filter(i=>{
    const actual=[i.getState_X(),i.getState_Y(),i.getState_Width(),i.getState_Height()];
    return actual.every((v,j)=>Math.abs(v-target.bbox[j])<.06)&&Math.abs(i.getState_Rotation())<.001&&i.getState_HorizonMirror()===[2,4,6].includes(target.layer);
   });
   if(matches.length!==1)throw Error('目标位置不匹配、已修复或匹配不唯一，停止修改。');
   oldIds.push(matches[0].getState_PrimitiveId());
  }
  if(new Set(oldIds).size!==oldIds.length)throw Error('目标图元重复，停止修改。');
  for(const item of p.newItems){
   const polygon=eda.pcb_MathPolygon.createComplexPolygon(item.source);
   if(!polygon)throw Error('修复多边形创建失败。');
   const [x,y,w,h]=item.bbox;
   const image=await eda.pcb_PrimitiveImage.create(x,y,polygon,item.layer,w,h,0,[2,4,6].includes(item.layer),false);
   if(!image)throw Error('新修复图元创建失败。');
   created.push(image.getState_PrimitiveId());
  }
  if(oldIds.length){
   deletionStarted=true;
   if(!(await eda.pcb_PrimitiveImage.delete(oldIds)))throw Error('旧图元替换未确认，请检查画布，不要重复运行。');
  }
  for(const [layer,count] of Object.entries(p.newCounts)){
   if((await eda.pcb_PrimitiveImage.getAll(Number(layer))).length!==count)throw Error('修复后图元数量不匹配，请检查画布。');
  }
  const saved=await eda.pcb_Document.save();
  eda.sys_Dialog.showInformationMessage('局部修复完成；云端保存'+(saved?'成功':'未确认，请手动保存')+'。请在预览点导入更新，制板前重新导出Gerber。','PCB 局部修复','知道了');
 }catch(e){
  if(!deletionStarted&&created.length)await eda.pcb_PrimitiveImage.delete(created);
  eda.sys_Dialog.showInformationMessage(String(e)+(deletionStarted?'\\n替换过程已开始，请检查当前画布，不要重复运行。':'\\n原有图元未替换。'),'PCB 修复检查','知道了');
 }
})();
'''

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before',type=Path,required=True)
    parser.add_argument('--after',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--document-uuid')
    args=parser.parse_args()
    if args.out.exists():parser.error('Output already exists; choose a new script path')
    try:
        before=json.loads(args.before.read_text(encoding='utf8'));after=json.loads(args.after.read_text(encoding='utf8'))
        pcb.inspect(before,1);_,_,_,checks=pcb.inspect(after,1)
        if not checks['passed_geometry_checks']:raise ValueError('After geometry fails checks; repair it before creating a CAD patch')
        patch=plan(before,after)
        if args.document_uuid:patch['documentUuid']=args.document_uuid
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(TEMPLATE.replace('__PLAN__',json.dumps(patch,separators=(',',':'),ensure_ascii=False)),encoding='utf8')
    except (ValueError,OSError,KeyError,TypeError) as e:parser.exit(2,'Patch build failed: '+str(e)+'\n')
    print(json.dumps({'old_images_replaced':len(patch['oldTargets']),'new_images_created':len(patch['newItems']),'native_eda_execution':'Not executed'},indent=2))

if __name__=='__main__':main()
