#!/usr/bin/env python3
"""Build technical PCB layers; does not generate or creatively edit artwork."""
from pathlib import Path
import argparse
import json
import math
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from shapely.affinity import scale, translate
from shapely.geometry import Polygon, Point, LineString, box
from shapely.geometry.polygon import orient
from shapely.ops import unary_union, nearest_points

MIL = 0.0254
EPS = 1e-6


def parts(geom):
    if geom.is_empty:
        return []
    if geom.geom_type == 'Polygon':
        return [geom]
    if geom.geom_type == 'MultiPolygon':
        return list(geom.geoms)
    if geom.geom_type == 'GeometryCollection':
        return [p for g in geom.geoms for p in parts(g)]
    if geom.area == 0:
        return []
    raise ValueError('Expected polygon geometry, got '+geom.geom_type)


def from_mask(mask, factor):
    contours, hierarchy = cv2.findContours(mask.astype(np.uint8), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None:
        return Polygon()
    polygons = []
    for i, contour in enumerate(contours):
        if hierarchy[0][i][3] != -1 or cv2.contourArea(contour) < 1:
            continue
        outer = cv2.approxPolyDP(contour, .16, True)[:, 0, :] * factor
        holes = []
        child = hierarchy[0][i][2]
        while child != -1:
            if cv2.contourArea(contours[child]) >= 1:
                holes.append(cv2.approxPolyDP(contours[child], .16, True)[:, 0, :] * factor)
            child = hierarchy[0][child][0]
        if len(outer) >= 3:
            polygons.extend(parts(Polygon(outer, [h for h in holes if len(h) >= 3]).buffer(0)))
    return unary_union(polygons) if polygons else Polygon()


def encoded_path(coords):
    xy = [(round(x/MIL, 4), round(-y/MIL, 4)) for x, y in coords]
    return [*xy[0], 'L', *[v for p in xy[1:] for v in p]]


def sources(geom):
    result = []
    pending=[(p,0) for p in parts(geom)]
    while pending:
        polygon,attempt=pending.pop(0)
        polygon=orient(polygon,sign=1)
        source=[encoded_path(polygon.exterior.coords)]+[encoded_path(h.coords) for h in polygon.interiors]
        decoded=Polygon(decoded_path(source[0]),[decoded_path(h) for h in source[1:]])
        if not decoded.is_valid:
            clean=decoded.buffer(0)
            # Only correct serialization slivers (<0.01mm, <1e-5mm2), never repair an
            # arbitrary malformed source or silently remove visible details.
            if attempt>=3 or clean.is_empty or polygon.symmetric_difference(clean).area>1e-5 or polygon.hausdorff_distance(clean)>.01:
                raise ValueError('Polygon became invalid when encoded; review the feature before CAD import')
            pending.extend((p,attempt+1) for p in parts(clean))
        else:result.append(source)
    return result


def decoded_path(path):
    if not isinstance(path, list) or len(path) < 9 or path[2] != 'L':
        raise ValueError('Only closed polygon paths [x,y,"L",...] are supported')
    a = path[:2] + path[3:]
    if len(a) % 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in a):
        raise ValueError('Invalid polygon coordinates')
    points = [(a[i]*MIL, -a[i+1]*MIL) for i in range(0, len(a), 2)]
    if points[0] != points[-1]:
        raise ValueError('Polygon path is not closed')
    return points


def decode_sources(data):
    polygons = []
    for source in data:
        if not source:
            raise ValueError('Empty complex polygon')
        polygon = Polygon(decoded_path(source[0]), [decoded_path(h) for h in source[1:]])
        if not polygon.is_valid or polygon.is_empty:
            raise ValueError('Invalid complex polygon')
        polygons.append(polygon)
    return unary_union(polygons) if polygons else Polygon()


def copper_under_art(art):
    copper = art.buffer(.06)
    for _ in range(5):
        islands = parts(copper)
        joins = []
        for i, p in enumerate(islands):
            for q in islands[i+1:]:
                if p.distance(q) < .20:
                    a, b = nearest_points(p, q)
                    joins.append(LineString([a, b]).buffer(.10))
        if not joins:
            break
        copper = unary_union([copper, *joins]).simplify(.008, preserve_topology=True)
    return copper


def build_image(args):
    if args.back is None:
        raise ValueError('Choose --back full, gold-only, none or custom explicitly')
    rgba = np.array(Image.open(args.image).convert('RGBA'))
    image_size = (rgba.shape[1], rgba.shape[0])

    def read_mask(path):
        mask = Image.open(path).convert('RGBA')
        if mask.size != image_size:
            raise ValueError('All source masks must have the same dimensions as the source image')
        a = np.array(mask)
        return (np.array(mask.convert('L')) < 128) & (a[:, :, 3] > 180)

    if args.silhouette_mask:
        alpha = read_mask(args.silhouette_mask)
    elif args.background == 'white':
        alpha = (rgba[:, :, 3] > 180) & (np.min(rgba[:, :, :3],axis=2) < args.background_threshold)
    else:
        alpha = rgba[:, :, 3] > 180
        if alpha.all():
            raise ValueError('Opaque input: provide --silhouette-mask or explicitly choose --background white')
    if not alpha.any():
        raise ValueError('No usable character silhouette')

    gold_mask = args.gold_front_mask or args.art_mask
    if gold_mask:
        gold = read_mask(gold_mask)
    elif args.legacy_gold_detection:
        gold = (rgba[:, :, 3] > 180) & (rgba[:, :, 2] < 180) & (rgba[:, :, 0] > 85) & (rgba[:, :, 1] < 225)
    else:
        raise ValueError('Provide --gold-front-mask; automatic colour classification is not a general separator')
    white_front = read_mask(args.silk_front_mask) if args.silk_front_mask else np.zeros_like(alpha)
    gold_back = read_mask(args.gold_back_mask) if args.gold_back_mask else None
    white_back = read_mask(args.silk_back_mask) if args.silk_back_mask else None
    if args.back != 'custom' and (gold_back is not None or white_back is not None):
        raise ValueError('Back masks require --back custom; other modes copy or omit layers explicitly')
    if args.back == 'custom' and gold_back is None and white_back is None:
        raise ValueError('--back custom requires at least one back mask')
    if not gold.any():
        raise ValueError('No gold art found; review the front gold mask')

    # Foreground source pixels define one outer material contour. White face
    # pixels inside an opaque white-background source need not be foreground.
    ys, xs = np.where(alpha)
    crop = (slice(ys.min(),ys.max()+1),slice(xs.min(),xs.max()+1))
    crop_px = [int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
    alpha = alpha[crop]
    contours,_ = cv2.findContours(alpha.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    contours = [c for c in contours if cv2.contourArea(c)>=1]
    if len(contours)!=1:
        raise ValueError('Silhouette has detached components; join intended parts in the silhouette mask instead of silently dropping them')
    contour = cv2.approxPolyDP(contours[0],.16,True)[:,0,:]
    radius = args.hole/2+args.ear_wall

    def board_at(factor):
        silhouette = Polygon(contour*factor).buffer(0)
        if silhouette.geom_type!='Polygon':
            raise ValueError('Source outer contour is not a single valid polygon')
        body = silhouette.buffer(args.outline_margin,quad_segs=16)
        body = body.buffer(.6).buffer(-.6)
        cx = body.bounds[0]+args.ear_x_fraction*(body.bounds[2]-body.bounds[0])
        half_neck = max(args.hole/2+.6,radius-.8)
        centre = body.intersection(box(cx-half_neck,-radius*8,cx+half_neck,body.bounds[3]+1))
        if centre.is_empty:
            raise ValueError('No body below chosen hanging-ear position')
        centre_top = centre.bounds[1]
        cy = centre_top-args.hole/2-.85+args.ear_shift_y_mm
        ear = Point(cx,cy).buffer(radius,quad_segs=48)
        neck = box(cx-half_neck,cy,cx+half_neck,centre_top+1.4)
        board = unary_union([body,ear,neck]).buffer(.35).buffer(-.35).simplify(.014,preserve_topology=True)
        components = sorted(parts(board),key=lambda p:p.area,reverse=True)
        if not components or any(p.area>EPS for p in components[1:]):
            raise ValueError('Ear and body do not form a single board')
        return components[0],cx,cy,silhouette

    factor = max(.0001,args.height/max(1,alpha.shape[0]-1))
    for _ in range(30):
        board,cx,cy,silhouette = board_at(factor)
        change = min(args.width/(board.bounds[2]-board.bounds[0]),args.height/(board.bounds[3]-board.bounds[1]))
        factor *= change
        if abs(change-1)<1e-10:break
    board,cx,cy,silhouette = board_at(factor)
    if board.bounds[2]-board.bounds[0]>args.width+.001 or board.bounds[3]-board.bounds[1]>args.height+.001:
        raise ValueError('Envelope cannot fit chosen hanging-ear parameters')
    hole = Point(cx,cy).buffer(args.hole/2,quad_segs=64)
    if not board.contains(hole):raise ValueError('Hole is not wholly inside the board')
    safe = board.buffer(-args.copper_edge).difference(hole.buffer(args.copper_hole))

    raw_gold = from_mask(gold[crop],factor)
    front = raw_gold
    # Defaults retain all vectorized strokes. Destructive reduction is opt-in,
    # and the report measures any loss relative to the raw vector geometry.
    if args.erosion:front = front.buffer(-args.erosion)
    if args.min_detail:front = front.buffer(-args.min_detail/2).buffer(args.min_detail/2)
    if args.min_island_area:front = unary_union([p for p in parts(front) if p.area>=args.min_island_area])
    if args.rounding:front = front.buffer(args.rounding,quad_segs=4)
    if args.reinforce_thin:
        thin = raw_gold.difference(raw_gold.buffer(-.065,quad_segs=4).buffer(.065,quad_segs=4))
        front = unary_union([front,thin.buffer(args.reinforce_thin,quad_segs=4)])
    front = front.intersection(safe.buffer(-.015))
    if front.is_empty:raise ValueError('No gold remains in the safe board region')
    if args.gold_hole_ring:
        ring = hole.buffer(.64).difference(hole.buffer(.32)).intersection(safe)
        front = unary_union([front,ring])

    def silk_from(mask,opening):
        silk = from_mask(mask[crop],factor).intersection(silhouette)
        if args.silk_pinhole_area:
            silk = unary_union([Polygon(p.exterior,[h.coords for h in p.interiors if Polygon(h).area>=args.silk_pinhole_area]) for p in parts(silk)])
        silk = silk.difference(opening.buffer(args.silk_clearance,quad_segs=8))
        return silk.intersection(board.buffer(-.3)).difference(hole.buffer(.4))

    silk_front = silk_from(white_front,front)
    if args.back in ('full','gold-only'):
        back = front
        silk_back = silk_front if args.back=='full' else Polygon()
    elif args.back=='none':
        back,silk_back = Polygon(),Polygon()
    else:
        back = from_mask(gold_back[crop],factor).intersection(safe.buffer(-.015)) if gold_back is not None else Polygon()
        silk_back = silk_from(white_back,back) if white_back is not None else Polygon()
    if args.copper_mode=='solid':
        copper_front,copper_back = safe,safe
    else:
        copper_front = copper_under_art(front).intersection(safe)
        copper_back = copper_under_art(back).intersection(safe)

    dx,dy = -board.bounds[0],-board.bounds[1]
    board,front,back,copper_front,copper_back,silk_front,silk_back = [translate(g,dx,dy) for g in (board,front,back,copper_front,copper_back,silk_front,silk_back)]
    loss = raw_gold.difference(translate(front,-dx,-dy)).area
    return {'version':3,'outline':encoded_path(board.exterior.coords),'front':sources(front),'back':sources(back),
            'copperFront':sources(copper_front),'copperBack':sources(copper_back),
            'silkFront':sources(silk_front),'silkBack':sources(silk_back),
            'hole':[(cx+dx)/MIL,-(cy+dy)/MIL,args.hole/MIL],
            'process':{'layers':2,'mask':args.mask_color,'silk':args.silk_color,'finish':'ENIG','thickness_mm':args.thickness},
            'raw_gold_preserved_percent':100*(1-loss/raw_gold.area) if raw_gold.area else None,
            'source_transform':{'crop_px':crop_px,'mm_per_source_pixel':factor,'offset_mm_y_down':[dx,dy]},
            'parameters':{'height_limit_mm':args.height,'width_limit_mm':args.width,'back':args.back,
                          'erosion_mm':args.erosion,'min_detail_mm':args.min_detail,'copper_mode':args.copper_mode,
                          'gold_limit':args.gold_limit,'silk_clearance_mm':args.silk_clearance}}


def inspect(data, gold_limit):
    required = ['outline', 'front', 'back', 'copperFront', 'copperBack', 'hole']
    if any(k not in data for k in required):
        raise ValueError('Geometry is missing required fields')
    board = Polygon(decoded_path(data['outline']))
    if not board.is_valid or board.is_empty or board.interiors:
        raise ValueError('Invalid board outline')
    h = data['hole']
    if len(h) != 3 or any(type(v) not in (int, float) or not math.isfinite(v) for v in h) or h[2] <= 0:
        raise ValueError('Invalid NPTH hole')
    hole = Point(h[0]*MIL, -h[1]*MIL).buffer(h[2]*MIL/2, quad_segs=48)
    material = board.difference(hole)
    if material.area <= 0:
        raise ValueError('No board material')
    data.setdefault('silkFront',[])
    data.setdefault('silkBack',[])
    layers = {k: decode_sources(data[k]) for k in [*required[1:5],'silkFront','silkBack']}
    checks = {'size_mm': [board.bounds[2]-board.bounds[0], board.bounds[3]-board.bounds[1]],
              'hole_mm': h[2]*MIL, 'area_mm2': material.area,
              'hole_fully_inside_board': board.contains(hole),
              'hole_edge_clearance_mm': hole.distance(board.exterior), 'faces': {}}
    for face, mask_key, copper_key, silk_key in [('front','front','copperFront','silkFront'),('back','back','copperBack','silkBack')]:
        mask, copper = layers[mask_key], layers[copper_key]
        silk = layers[silk_key]
        islands = parts(copper)
        gaps = [p.distance(q) for i, p in enumerate(islands) for q in islands[i+1:]]
        f = {'gold_mm2': mask.intersection(copper).intersection(material).area,
             'copper_board_clearance_mm': copper.distance(board.exterior) if islands else None,
             'copper_hole_clearance_mm': copper.distance(hole) if islands else None,
             'copper_island_gap_mm': min(gaps) if gaps else None,
             'copper_outside_board_mm2': copper.difference(board).area,
             'copper_hole_overlap_mm2': copper.intersection(hole).area,
             'opening_without_copper_mm2': mask.difference(copper).area,
             'opening_outside_material_mm2': mask.difference(material).area,
             'silk_over_opening_mm2':silk.intersection(mask).area,
             'silk_outside_material_mm2':silk.difference(material).area,
             'silk_opening_clearance_mm':silk.distance(mask) if not silk.is_empty and not mask.is_empty else None,
             'copper_islands': len(islands), 'mask_polygons': len(data[mask_key]),'silk_polygons':len(data[silk_key])}
        f['passed'] = (all(f[k] <= EPS for k in ['copper_outside_board_mm2', 'copper_hole_overlap_mm2',
                                                'opening_without_copper_mm2','opening_outside_material_mm2',
                                                'silk_over_opening_mm2','silk_outside_material_mm2'])
                       and (f['copper_board_clearance_mm'] is None or f['copper_board_clearance_mm'] >= .2999)
                       and (f['copper_hole_clearance_mm'] is None or f['copper_hole_clearance_mm'] >= .1999)
                       and (f['copper_island_gap_mm'] is None or f['copper_island_gap_mm'] >= .1269)
                       and (f['silk_opening_clearance_mm'] is None or f['silk_opening_clearance_mm'] >= .0999))
        checks['faces'][face] = f
    checks['gold_surface_ratio'] = sum(f['gold_mm2'] for f in checks['faces'].values())/(2*material.area)
    checks['within_gold_limit'] = checks['gold_surface_ratio'] <= gold_limit
    checks['passed_geometry_checks'] = (checks['hole_fully_inside_board'] and checks['hole_edge_clearance_mm'] >= 1
                                       and all(f['passed'] for f in checks['faces'].values()))
    checks['limitations'] = 'Selected polygon clearance checks only; narrow necks, internal slots and factory DFM still require review. Not proof of coupon eligibility.'
    checks['raw_gold_preserved_percent']=data.get('raw_gold_preserved_percent')
    checks['validation_stage']='Local geometric checks; native EDA execution and factory DFM are separate'
    data.update({'bounds': list(board.bounds), 'size_mm': checks['size_mm'], 'hole_mm': checks['hole_mm'],
                 'area_mm2': material.area, 'front_gold_mm2': checks['faces']['front']['gold_mm2'],
                 'back_gold_mm2': checks['faces']['back']['gold_mm2'],
                 'gold_surface_ratio': checks['gold_surface_ratio'],
                 'gold_ratio_definition': 'top+bottom exposed copper / top+bottom board material area'})
    return board, hole, layers, checks


def svg_path(geom):
    return ' '.join('M'+' L'.join(f'{x:.4f},{y:.4f}' for x, y in ring.coords)+' Z'
                    for p in parts(geom) for ring in [p.exterior, *p.interiors])


def render_mask(geom, bounds, px):
    minx, miny, maxx, maxy = bounds
    im = Image.new('L', (math.ceil((maxx-minx)*px)+1, math.ceil((maxy-miny)*px)+1), 0)
    draw = ImageDraw.Draw(im)
    def conv(p): return ((p[0]-minx)*px, (p[1]-miny)*px)
    for p in sorted(parts(geom), key=lambda p: p.area, reverse=True):
        draw.polygon([conv(q) for q in p.exterior.coords], fill=255)
        for h in p.interiors:
            draw.polygon([conv(q) for q in h.coords], fill=0)
    return im


def write_manufacturing_requirements(data, checks, out):
    process = data.get('process', {})
    finish = process.get('finish')
    requirements = {
        'design_process': process,
        'surface_finish_required': finish,
        'order_field_zh': '焊盘喷镀 / 表面处理',
        'manual_order_selection_required': True,
        'actual_order_finish_confirmed': False,
        'script_sets_factory_finish': False,
        'size_mm': checks['size_mm'],
        'hole_mm': checks['hole_mm'],
        'exposed_copper_mm2': {face: info['gold_mm2'] for face, info in checks['faces'].items()},
        'exposed_copper_ratio': checks['gold_surface_ratio'],
        'notice': 'Design requirements only. Confirm the actual order finish separately; preview colours and metadata do not select a factory process.',
    }
    (out/'manufacturing_requirements.json').write_text(json.dumps(requirements, indent=2, ensure_ascii=False), encoding='utf8')
    finish_text = '沉金 ENIG（目标金色）' if finish == 'ENIG' else str(finish or '未指定，请确认目标表面处理')
    note = (
        '装饰 PCB 下单工艺要求\n\n'
        f'焊盘喷镀 / 表面处理：{finish_text}\n'
        '请在实际订单中明确选择并核对；本文件、JSON及预览颜色均不自动设置订单工艺。\n'
        '实际订单表面处理：尚未确认。\n\n'
        f"板层：{process.get('layers', '未指定')}\n"
        f"建议板厚：{process.get('thickness_mm', '未指定')} mm\n"
        f"阻焊颜色：{process.get('mask', '未指定')}；丝印颜色：{process.get('silk', '未指定')}\n"
        f"尺寸：{checks['size_mm'][0]:.2f} × {checks['size_mm'][1]:.2f} mm；挂孔：{checks['hole_mm']:.2f} mm NPTH\n"
        f"双面平均露铜比例：{checks['gold_surface_ratio']*100:.2f}%（不是优惠资格证明）\n\n"
        '提交生产前核对实际Gerber、生产稿及订单工艺。若目标为金色，表面处理须选沉金；不据预览推定已经选择。\n'
        '本工具不提交或更改订单。工厂审核、报价及优惠资格需另外核验。\n'
    )
    (out/'下单工艺要求.txt').write_text(note, encoding='utf8')


def export(data, board, hole, layers, checks, out):
    out.mkdir(parents=True, exist_ok=True)
    (out/'geometry.json').write_text(json.dumps(data, separators=(',', ':'), ensure_ascii=False), encoding='utf8')
    (out/'checks.json').write_text(json.dumps(checks, indent=2, ensure_ascii=False), encoding='utf8')
    template = (Path(__file__).resolve().parents[1]/'assets/create_in_eda.template.js').read_text(encoding='utf8')
    (out/'create_in_eda.js').write_text(template.replace('__GEOMETRY_JSON__', json.dumps(data, separators=(',', ':'))), encoding='utf8')
    write_manufacturing_requirements(data, checks, out)
    dxf = ['0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES',
           '0','POLYLINE','8','BOARD_OUTLINE','66','1','70','1','10','0','20','0','30','0']
    for x, y in list(board.exterior.coords)[:-1]:
        dxf += ['0','VERTEX','8','BOARD_OUTLINE','10',f'{x:.6f}','20',f'{-y:.6f}','30','0']
    dxf += ['0','SEQEND','0','ENDSEC','0','EOF']
    (out/'board_outline.dxf').write_text('\n'.join(dxf)+'\n', encoding='ascii')
    minx, miny, maxx, maxy = bounds = board.bounds
    mid = (minx+maxx)/2
    body = board.difference(hole)
    views = [('front', body, layers['front'],layers['silkFront']),
             ('back', scale(body, xfact=-1, yfact=1, origin=(mid,0)),
              scale(layers['back'], xfact=-1, yfact=1, origin=(mid,0)),
              scale(layers['silkBack'], xfact=-1, yfact=1, origin=(mid,0)))]
    colours={'white':'#fffefa','purple':'#331044','green':'#174f35','blue':'#0c3159','black':'#161616','red':'#8d1623','yellow':'#d7b52a'}
    process=data.get('process',{})
    mask_colour=colours.get(process.get('mask','white'),'#fffefa')
    silk_colour=colours.get(process.get('silk','white'),'#fffefa')
    for side, silhouette, art, silk in views:
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{maxx-minx:.4f}mm" height="{maxy-miny:.4f}mm" '
               f'viewBox="{minx} {miny} {maxx-minx} {maxy-miny}"><path d="{svg_path(silhouette)}" fill="{mask_colour}" '
               f'stroke="#888" stroke-width=".04" fill-rule="evenodd"/><path d="{svg_path(art)}" '
               f'fill="#d8b554" fill-rule="evenodd"/><path d="{svg_path(silk)}" fill="{silk_colour}" fill-rule="evenodd"/></svg>')
        (out/f'{side}.svg').write_text(svg, encoding='utf8')
    px = min(18, 820/(maxy-miny), 650/(maxx-minx))
    w, h = math.ceil((maxx-minx)*px)+1, math.ceil((maxy-miny)*px)+1
    preview = Image.new('RGB', (w*2+120, h+140), '#eee9e2')
    font = ImageFont.load_default(size=19)
    draw = ImageDraw.Draw(preview)
    for i, (side, silhouette, art, silk) in enumerate(views):
        location = (40+i*(w+40), 55)
        white = Image.new('RGB', (w,h), mask_colour)
        gold = Image.new('RGB', (w,h), '#d8b554')
        silk_image = Image.new('RGB',(w,h),silk_colour)
        preview.paste(white, location, render_mask(silhouette,bounds,px))
        preview.paste(gold, location, render_mask(art,bounds,px))
        preview.paste(silk_image,location,render_mask(silk,bounds,px))
        draw.text((location[0],18),side.upper(),font=font,fill='#333333')
    draw.text((40,h+72),f'{maxx-minx:.2f} x {maxy-miny:.2f} mm | NPTH {checks["hole_mm"]:.2f} mm | Gold {checks["gold_surface_ratio"]*100:.2f}%',font=font,fill='#333333')
    preview.save(out/'preview.png')
    for key, geom in layers.items():
        mask = render_mask(geom,bounds,64)
        Image.fromarray(255-np.array(mask)).save(out/f'layer_{key}.png')
    placement = {'width_mm': maxx-minx, 'height_mm': maxy-miny,
                 'left_x_mm': minx, 'top_y_mm': -miny, 'bounds_mm_y_down': list(bounds),
                 'note': 'All layer masks use identical canvas; black is the layer geometry. Verify bottom mirror in EDA.'}
    (out/'placement.json').write_text(json.dumps(placement,indent=2),encoding='utf8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--image', type=Path)
    source.add_argument('--geometry', type=Path)
    parser.add_argument('--art-mask', type=Path)
    parser.add_argument('--gold-front-mask',type=Path)
    parser.add_argument('--gold-back-mask',type=Path)
    parser.add_argument('--silk-front-mask',type=Path)
    parser.add_argument('--silk-back-mask',type=Path)
    parser.add_argument('--silhouette-mask',type=Path)
    parser.add_argument('--background',choices=['alpha','white'],default='alpha')
    parser.add_argument('--background-threshold',type=int,default=230)
    parser.add_argument('--legacy-gold-detection',action='store_true')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--height', type=float, default=55.6)
    parser.add_argument('--width', type=float, default=46.5)
    parser.add_argument('--hole', type=float, default=2)
    parser.add_argument('--ear-wall', type=float, default=1.7)
    parser.add_argument('--outline-margin', type=float, default=.9)
    parser.add_argument('--back', choices=['full','gold-only','none','custom'])
    parser.add_argument('--erosion', type=float, default=0)
    parser.add_argument('--min-detail', type=float, default=0)
    parser.add_argument('--min-island-area', type=float, default=0)
    parser.add_argument('--rounding',type=float,default=0)
    parser.add_argument('--reinforce-thin',type=float,default=0)
    parser.add_argument('--silk-pinhole-area',type=float,default=0)
    parser.add_argument('--silk-clearance',type=float,default=.12)
    parser.add_argument('--copper-edge',type=float,default=.34)
    parser.add_argument('--copper-hole',type=float,default=.32)
    parser.add_argument('--copper-mode',choices=['solid','art'],default='solid')
    parser.add_argument('--mask-color',choices=['white','purple','green','blue','black','red','yellow'],default='white')
    parser.add_argument('--silk-color',choices=['white','black'],default='white')
    parser.add_argument('--thickness',type=float,default=1.6)
    parser.add_argument('--ear-x-fraction',type=float,default=.5)
    parser.add_argument('--ear-shift-y-mm',type=float,default=0)
    parser.add_argument('--gold-hole-ring',action='store_true')
    parser.add_argument('--gold-limit', type=float, default=.20)
    args = parser.parse_args()
    if args.out.exists() and (not args.out.is_dir() or any(args.out.iterdir())):
        parser.error('Output must be absent or an empty directory; choose a new version path')
    if args.geometry and (any([args.art_mask,args.gold_front_mask,args.gold_back_mask,args.silk_front_mask,args.silk_back_mask,args.silhouette_mask]) or args.back is not None):
        parser.error('--geometry preserves layers; do not pass masks or --back')
    if args.art_mask and args.gold_front_mask:parser.error('--art-mask is an alias; use only one front gold mask option')
    if any(not math.isfinite(v) or v <= 0 for v in [args.height,args.width,args.hole,args.ear_wall,args.outline_margin]):
        parser.error('Size and material parameters must be finite and positive')
    if any(not math.isfinite(v) or v < 0 for v in [args.erosion,args.min_detail,args.min_island_area,args.rounding,args.reinforce_thin,args.silk_pinhole_area]) or not 0 < args.gold_limit <= 1:
        parser.error('Invalid cleanup parameters or gold limit')
    if any(not math.isfinite(v) or v<=0 for v in [args.silk_clearance,args.copper_edge,args.copper_hole,args.thickness]) or not 0<args.ear_x_fraction<1 or not math.isfinite(args.ear_shift_y_mm) or not 1<=args.background_threshold<=255:
        parser.error('Invalid process, ear-position or clearance parameters')
    try:
        data = json.loads(args.geometry.read_text(encoding='utf8')) if args.geometry else build_image(args)
        board, hole, layers, checks = inspect(data,args.gold_limit)
        export(data,board,hole,layers,checks,args.out)
    except (ValueError, OSError, KeyError, TypeError) as error:
        parser.exit(2, 'PCB build failed: '+str(error)+'\n')
    print(json.dumps({k: checks[k] for k in ['size_mm','hole_mm','gold_surface_ratio','within_gold_limit','passed_geometry_checks']},indent=2))
    print('Output:',args.out.resolve())
    if not checks['passed_geometry_checks']:
        print('REVIEW REQUIRED: failed selected geometry checks; inspect checks.json before CAD import.',file=sys.stderr)
    if not checks['within_gold_limit']:
        print('Gold exceeds configured area limit; artwork has NOT been automatically removed.',file=sys.stderr)


if __name__ == '__main__':
    main()
