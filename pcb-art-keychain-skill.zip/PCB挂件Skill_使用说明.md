# PCB 挂件 Skill 使用说明

这套流程让 AI 在本地完成图案分色、制造图形、检查和 JavaScript，用户在嘉立创 EDA 专业版运行脚本。无需 AI 控制浏览器，也无需给 AI 账户密码。包内版本为 **2.0.0**。

## 给其他 AI 使用

1. 解压 `pcb-art-keychain-skill.zip`，保留完整的 `pcb-art-keychain` 文件夹。
2. 将整个文件夹交给能读取本地文件、运行 Python 的 AI。支持 Skills 的客户端可按其规则安装；不支持的客户端直接读取 `SKILL.md` 和其引用资料也能使用。
3. 同时提供参考图片和需求。不要只发 `SKILL.md`：脚本、模板、参考文档和案例素材都是包的一部分。

可直接发送：

```text
请读取 pcb-art-keychain/SKILL.md，并按其中的脚本工作流制作我附图中的 PCB 挂件。
请先从参考图确定分色，保护眼睛、睫毛、蕾丝和其他细线。
尺寸：宽不超过55.6mm，高不超过66.2mm，均包含挂耳；保持人物比例。
挂孔：2mm非金属化通孔，检查孔边材料及挂耳连接。
正面：紫色阻焊、金色线条、普通白丝印。
背面：完整紫金图案，不放白丝印。
请在本地生成制造几何、正反面工艺预览、几何检查报告和完整 EDA JavaScript。
有毛刺时先局部修复并给出对比，不要全图腐蚀或删除细节。
优先考虑免费条件；免费结论必须重新查询当前官方活动和我的实际券，没有证据就标明待核验。
我会在嘉立创 EDA 专业版手动录入脚本，不需要控制浏览器。
交付完整文件与运行、预览、保存步骤，并区分本地检查和实际 EDA 核验。
```

这些尺寸、孔径和背面方案只是示例，可替换成自己的要求。双面白金、双面紫白金、独立背面和空白背面均可做，不能默认为每个角色使用本案例的颜色与坐标。

本机现有 `pcb-art-keychain` 已更新；新会话可用 `$pcb-art-keychain` 调用。如果其他客户端不识别名称，就明确要求读取解压文件夹中的 `SKILL.md`。

## 在 EDA 中录入

1. 打开 **嘉立创 EDA 专业版**，在工程中新建空白 PCB，打开 PCB 图页并点击画布。
2. 打开 **高级 → 运行脚本**。
3. 导入 AI 交付的 `create_in_eda.js`，或全选代码框后粘贴全文。
4. 点击运行一次，读取结果提示。已有图元会触发拒绝，换新的空白 PCB。
5. 打开 2D/3D 预览，执行 **导入更新**，设置真实阻焊、金属和丝印颜色，查看两面与贯穿孔。
6. 核对 DRC、保存状态，再从 EDA 导出原生工程和制板 Gerber。修改后重新导出。

`patch_in_eda.js` 是修复已有板的补丁，只在与修复前版本匹配的 PCB 执行。它与首次生成脚本用途不同；执行中断先检查画布，不连续重复运行。

## 直接复现这次库洛米

包内已包含：

- `assets/example-kuromi-preview.png`：局部去毛刺后的正反面工艺示意。
- `assets/example-kuromi-create.js`：修复版完整生成脚本，在新空白 PCB 运行。
- `assets/example-kuromi-patch.js`：修复前 original 几何对应的现有板补丁。
- `assets/example-kuromi-original.json`、`example-kuromi-clean.json`：修复前后制造几何。
- `assets/example-kuromi-repairs.json`、`example-kuromi-face-comparison.png`：明确的修复位置与局部对比。

该案例约 **55.60×65.89mm**，孔径 **2.00mm**，正面紫白金，背面紫金；双面平均露铜面积约 **19.58%**。这不是账户免费资格或工厂审核的证明。

如需重新生成，从 skill 文件夹运行：

```text
python -m pip install -r scripts/requirements.txt
python scripts/build_pcb_art.py --geometry assets/example-kuromi-clean.json --out work/my-kuromi
```

输出包含 `create_in_eda.js`、`geometry.json`、`checks.json`、预览、DXF、SVG 和同坐标图层蒙版。输出目录须不存在或为空，避免覆盖上一次结果。完整命令与参数见 `references/helpers.md`。

## 包里解决了什么

| 内容 | 对应文件 |
|---|---|
| 工作流、工程约束、完成证据 | SKILL.md |
| 紫白金/白金分层和共同坐标 | references/colour-separation.md |
| 本地生成、双面方案、参数和输出 | references/helpers.md |
| 局部去毛刺、丝印补偿、已有板补丁 | references/repair.md |
| 用户录入、预览、保存、故障排查 | references/eda-workflow.md |
| 沉金公式及动态优惠查询 | references/free-pcb.md |
| EDA 接口签名与真实钻孔参数 | references/eda-api.md |
| 本次案例与验证边界 | references/worked-example.md |

默认不做统一收缩、全图开运算或按面积删除小图案。金色开窗下有铜，白丝印避让露金，正反面使用共同制造坐标。局部修复会同时处理相邻白丝印，避免留下旧毛刺位置的紫色缺口。

## 已做的检查

本地复现、四种背面方案、细线保留、输入/覆盖拒绝、局部变更范围、脚本语法和 API 模拟检查已通过。库洛米 Gerber 用独立解析器回读了铜、开窗、丝印、板框和 NPTH；它是直接几何导出，不是 EDA 原生导出。

包内 `assets/validation-summary.json` 记录检查范围。模拟执行不证明当前 EDA 版本实际兼容；升级模板的真实运行、云端保存、工厂 DFM 和实物效果仍需在用户录入后核验。
